package com.example.hospitalbackend.controller;

import com.example.hospitalbackend.entity.PatientCard;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/patient")
public class PatientCardController {
    private final PatientCardService patientCardService;

    @Autowired
    public PatientCardController(PatientCardService patientCardService) {
        this.patientCardService = patientCardService;
    }

    // 检查证件号是否已存在
    @GetMapping("/checkId")
    public ResponseEntity<?> checkIdNumber(@RequestParam String idNumber) {
        if (patientCardService.findCardByIdNumber(idNumber) != null) {
            return ResponseEntity.ok().body("该证件号已建档");
        }
        return ResponseEntity.ok().body("证件号可用");
    }

    // 创建诊疗卡
    @PostMapping("/create")
    public ResponseEntity<?> createPatientCard(@RequestBody PatientCard card) {
        try {
            String cardNumber = patientCardService.createPatientCard(card);
            return ResponseEntity.ok().body("建档成功！诊疗卡号：" + cardNumber);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    // 找回诊疗卡
    @GetMapping("/retrieve")
    public ResponseEntity<?> retrieveCard(@RequestParam String idNumber) {
        PatientCard card = patientCardService.findCardByIdNumber(idNumber);
        if (card != null) {
            return ResponseEntity.ok().body("找到诊疗卡：" + card.getCardNumber());
        }
        return ResponseEntity.badRequest().body("未找到相关诊疗卡");
    }
}
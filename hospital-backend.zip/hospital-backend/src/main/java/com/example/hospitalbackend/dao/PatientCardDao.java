package com.example.hospitalbackend.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import java.util.Map;

@Repository
public class PatientCardDao {
    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public PatientCardDao(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    // 检查证件号是否已存在
    public boolean isIdNumberExists(String idNumber) {
        String sql = "SELECT COUNT(*) FROM PATIENT_CARD WHERE ID_NUMBER = ?";
        int count = jdbcTemplate.queryForObject(sql, Integer.class, idNumber);
        return count > 0;
    }

    // 创建诊疗卡
    public String createPatientCard(PatientCard card) {
        // 生成诊疗卡号规则：HK/HM/TW + 年月日 + 序列号
        String sequenceSql = "SELECT PATIENT_CARD_SEQ.NEXTVAL FROM DUAL";
        Long seq = jdbcTemplate.queryForObject(sequenceSql, Long.class);
        String cardNumber = "HK" + new SimpleDateFormat("yyyyMMdd").format(new Date()) + String.format("%05d", seq);

        String sql = "INSERT INTO PATIENT_CARD (CARD_ID, CARD_NUMBER, IDENTITY_TYPE, NAME, " +
                "ID_TYPE, ID_NUMBER, GENDER, BIRTH_DATE, PHONE, ADDRESS, MEDICAL_TYPE, " +
                "GUARDIAN_NAME, GUARDIAN_PHONE, ID_PHOTO_PATH) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        jdbcTemplate.update(sql,
                seq, cardNumber, card.getIdentityType(), card.getName(),
                card.getIdType(), card.getIdNumber(), card.getGender(), card.getBirthDate(),
                card.getPhone(), card.getAddress(), card.getMedicalType(),
                card.getGuardianName(), card.getGuardianPhone(), card.getIdPhotoPath());

        return cardNumber;
    }

    // 根据证件号查询诊疗卡
    public PatientCard findByidNumber(String idNumber) {
        String sql = "SELECT * FROM PATIENT_CARD WHERE ID_NUMBER = ?";
        return jdbcTemplate.queryForObject(sql, (rs, rowNum) -> {
            PatientCard card = new PatientCard();
            card.setCardId(rs.getLong("CARD_ID"));
            card.setCardNumber(rs.getString("CARD_NUMBER"));
            // 设置其他属性...
            return card;
        }, idNumber);
    }
}
package com.example.hospitalbackend.entity;

import java.util.Date;

public class PatientCard {
    private Long cardId;          // 诊疗卡ID
    private String cardNumber;    // 诊疗卡号
    private Integer identityType; // 身份类型：0-成人 1-儿童
    private String name;          // 姓名
    private String idType;        // 证件类型
    private String idNumber;      // 证件号码
    private Integer gender;       // 性别：0-男 1-女
    private Date birthDate;       // 出生日期
    private String phone;         // 手机号
    private String address;       // 现住址
    private String medicalType;   // 医保类型
    private String guardianName;  // 监护人姓名
    private String guardianPhone; // 监护人手机
    private String idPhotoPath;   // 证件照片路径
    private Date createTime;      // 创建时间

    // Getters and Setters
    public Long getCardId() { return cardId; }
    public void setCardId(Long cardId) { this.cardId = cardId; }
    // 其他getter/setter方法...
}

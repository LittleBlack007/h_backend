package com.example.hospitalbackend.service;

import com.example.hospitalbackend.dao.PatientCardDao;
import com.example.hospitalbackend.entity.PatientCard;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class PatientCardService {
    private final PatientCardDao patientCardDao;

    @Autowired
    public PatientCardService(PatientCardDao patientCardDao) {
        this.patientCardDao = patientCardDao;
    }

    @Transactional
    public String createPatientCard(PatientCard card) {
        // 验证证件号是否已存在
        if (patientCardDao.isIdNumberExists(card.getIdNumber())) {
            throw new RuntimeException("该证件号已建档，请绑定现有诊疗卡");
        }

        // 儿童建档必须填写监护人信息
        if (card.getIdentityType() == 1) { // 1代表儿童
            if (card.getGuardianName() == null || card.getGuardianName().isEmpty() ||
                    card.getGuardianPhone() == null || card.getGuardianPhone().isEmpty()) {
                throw new RuntimeException("儿童建档必须填写监护人姓名和手机号");
            }
        }

        // 保存诊疗卡信息
        return patientCardDao.createPatientCard(card);
    }

    public PatientCard findCardByIdNumber(String idNumber) {
        return patientCardDao.findByidNumber(idNumber);
    }
}